window._config = {
    cognito: {
        userPoolId: 'us-east-1_MstqPu5fX', // e.g. us-east-2_uXboG5pAb
        userPoolClientId: '5c9s19ee9qkokn3ei1au71r2dl', // e.g. 25ddkmj4v6hfsfvruhpfi7n4hv
        region: 'us-east-1' // e.g. us-east-2
    },
    api: {
        invokeUrl: '' // e.g. https://rc7nyt4tql.execute-api.us-west-2.amazonaws.com/prod',
    }
};
